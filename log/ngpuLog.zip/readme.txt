How to view ngpu system log on linux computer? 
1. Copy ngpuLog.sh to linux computer
2. chmod +x ngpuLog.sh ; ./ngpuLog.sh. IMPORTANT: please keep this program running, without which, log file cannot be updated. 
3. There should one log file, ngpu.log. Use  tail -f ngpu.log. 